const s="/assets/github-CCjyc9k_.png",n="/assets/linkedin-nTesoqZ7.png",e="/assets/email-pYlDksNJ.png";export{e,s as g,n as l};
