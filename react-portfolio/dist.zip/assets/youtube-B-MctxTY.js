const s="/assets/medium1.0-tql9Ewbz.png",t="/assets/youtube-9BSdMHvg.png";export{s as m,t as y};
